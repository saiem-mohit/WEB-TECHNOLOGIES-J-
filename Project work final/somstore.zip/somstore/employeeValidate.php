<?php 

//include config.php to connect to the database
	include("config.php"); 
	
	//start session
    session_start();
{
		// Define $myusername and $mypassword
	$saiem=$_POST['saiem'];
	$mushfiq=$_POST['mushfiq'];
	
	// To protect MySQL injection
	$saiem= mysqli_real_escape_string( $mysqli,$saiem);
	$mushfiq = mysqli_real_escape_string( $mysqli, $mushfiq);

    $fetch=mysqli_query( $mysqli, "select Employee_ID from employee where Username='$saiem' and Password = '$mushfiq'");
    $count=mysqli_num_rows($fetch);
    if($count!="")
    {
    $_SESSION['login_username']=$saiem;
	 header("location: Admin/index.php");
    }
    else
    {
	   header('Location: Sign In.php');
	}

}
?>
